/* Raj Marketing Mysore - CENTRAL PRICE MASTER */
window.RM_PRICES = {
  gstRate: 0.18,
  maxDiscountPercent: 10,
  aluminiumStandardLengthFt: 12,
  products: {
    velcro:   { name:"Velcro System", ratePerSqft:60,  frameDeduction:false },
    frame:    { name:"Aluminium Frame System", ratePerSqft:180, frameDeduction:true },
    pleated:  { name:"Pleated Nets", ratePerSqft:350, frameDeduction:true },
    meshDoor: { name:"Mesh Door", ratePerSqft:380, frameDeduction:true }
  }
};
(function(){
  try {
    const saved = JSON.parse(localStorage.getItem("rm_price_overrides") || "null");
    if (saved) Object.keys(saved).forEach(k => {
      if (RM_PRICES.products[k] && Number.isFinite(Number(saved[k])) && Number(saved[k]) >= 0)
        RM_PRICES.products[k].ratePerSqft = Number(saved[k]);
    });
  } catch(e) {}
})();
window.RM_CALC = {
  normalizeDimension(v) {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.max(24,n) : 24;
  },
  effectiveDimension(v,key) {
    const n=this.normalizeDimension(v);
    return RM_PRICES.products[key]?.frameDeduction ? Math.max(0.5,n-1.5) : n;
  },
  sqft(w,h,q,key) {
    return this.effectiveDimension(w,key)*this.effectiveDimension(h,key)/144*(Number(q)||1);
  },
  middlePieces(h) {
    const ft=this.normalizeDimension(h)/12;
    return ft < 3 ? 1 : ft <= 5 ? 2 : 3;
  },
  aluminiumFeet(w,h,q,key) {
    if(!RM_PRICES.products[key]?.frameDeduction) return 0;
    const ew=this.effectiveDimension(w,key), eh=this.effectiveDimension(h,key), qty=Number(q)||1;
    return ((2*ew)+(2*eh)+(this.middlePieces(h)*eh))*qty/12;
  },
  money(n) {
    return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:2}).format(Number(n)||0);
  },
  words(n) {
    n=Math.round(Number(n)||0);
    if(!n) return "Zero Rupees Only";
    const o=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"];
    const t=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];
    const u100=x=>x<20?o[x]:t[Math.floor(x/10)]+(x%10?" "+o[x%10]:"");
    const u1000=x=>x<100?u100(x):o[Math.floor(x/100)]+" Hundred"+(x%100?" "+u100(x%100):"");
    const a=[];
    if(n>=10000000){a.push(u1000(Math.floor(n/10000000))+" Crore");n%=10000000}
    if(n>=100000){a.push(u100(Math.floor(n/100000))+" Lakh");n%=100000}
    if(n>=1000){a.push(u1000(Math.floor(n/1000))+" Thousand");n%=1000}
    if(n)a.push(u1000(n));
    return a.join(" ")+" Rupees Only";
  }
};
